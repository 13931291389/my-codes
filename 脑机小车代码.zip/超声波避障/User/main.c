#include "stm32f10x.h"
#include "systick.h"
#include "Motor.h"
#include "hcsr04.h"
#include "buzzer.h"
#include "usart.h"
#include "Delay.h"
#include "app_linewalking.h"
#include "bsp_linewalking.h"
#include "led.h"          // ✅ 添加LED头文件

extern int attention;

/*--------------------- 原有参数不变 ---------------------*/
#define OBSTACLE_THRESHOLD_CM   20.0f
#define ATTENTION_MIN           50
#define ATTENTION_MAX           100
#define ATTENTION_HOLD_TIME     1000
#define OBSTACLE_IN_CNT         3

#define SPEED_MIN               300
#define SPEED_MAX               999

#define OBSTACLE_SPEED          800
#define OBST_BACK_TIME_MS       900
#define OBST_TURN_TIME_MS       800
#define OBST_FORWARD_TIME_MS    1800

#define BUZZER_BEEP_MS          200

/*==================== 跟随参数 ====================*/
#define FOLLOW_TARGET_DIST      25.0f
#define FOLLOW_DEAD_ZONE        5.0f
#define FOLLOW_MAX_SPEED        600
#define FOLLOW_MIN_SPEED        150

/*==================== 按键参数 ====================*/
#define KEY_PORT                GPIOB
#define KEY_PIN                 GPIO_Pin_8
#define KEY_RCC                 RCC_APB2Periph_GPIOB
#define KEY_DEBOUNCE_MS         50

/*==================== 原有状态枚举 ====================*/
typedef enum {
    STATE_NORMAL,
    STATE_OBSTACLE
} SystemState;

typedef enum {
    OBST_ACTION_IDLE,
    OBST_ACTION_BACK,
    OBST_ACTION_TURN,
    OBST_ACTION_FORWARD,
} ObstacleAction;

/*==================== 模式枚举 ====================*/
typedef enum {
    MODE_LINEWALKING = 0,
    MODE_FOLLOW = 1
} RunMode;

/*==================== 跟随相关变量 ====================*/
static RunMode currentMode = MODE_LINEWALKING;
static float distance_filter[3];
static uint8_t filter_idx = 0;
static uint8_t filter_ready = 0;

static float follow_integral = 0;
static float follow_prev_error = 0;

/*==================== 按键相关变量 ====================*/
static uint8_t key_state = 0;
static uint32_t key_press_time = 0;

/*==================== 滑动平均滤波 ====================*/
float filter_distance(float new_dist)
{
    distance_filter[filter_idx] = new_dist;
    filter_idx = (filter_idx + 1) % 3;
    if (filter_idx == 0) filter_ready = 1;
    if (!filter_ready) return new_dist;
    
    float sum = 0;
    for (int i = 0; i < 3; i++) {
        sum += distance_filter[i];
    }
    return sum / 3.0f;
}

/*==================== 按键初始化 ====================*/
void Key_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(KEY_RCC, ENABLE);
    GPIO_InitStruct.GPIO_Pin = KEY_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(KEY_PORT, &GPIO_InitStruct);
}

/*==================== 按键扫描 ====================*/
uint8_t Key_Scan(void)
{
    uint8_t key_value = GPIO_ReadInputDataBit(KEY_PORT, KEY_PIN);
    
    switch (key_state) {
        case 0:
            if (key_value == 0) {
                key_state = 1;
                key_press_time = GetTick();
            }
            break;
        case 1:
            if (key_value == 0) {
                if (GetTick() - key_press_time >= KEY_DEBOUNCE_MS) {
                    key_state = 2;
                    return 1;
                }
            } else {
                key_state = 0;
            }
            break;
        case 2:
            if (key_value == 1) {
                key_state = 0;
            }
            break;
    }
    return 0;
}

/*==================== 模式切换 ====================*/
void Switch_Mode(void)
{
    if (currentMode == MODE_LINEWALKING) {
        currentMode = MODE_FOLLOW;
        Buzzer_StartAlarm(100);
        Delay_Ms(150);
        Buzzer_StartAlarm(100);
        USART1_SendString("Mode: FOLLOW\r\n");
    } else {
        currentMode = MODE_LINEWALKING;
        Buzzer_StartAlarm(200);
        USART1_SendString("Mode: LINEWALKING\r\n");
    }
    Car_Stop();
    follow_integral = 0;
    follow_prev_error = 0;
}

/*==================== 跟随控制 ====================*/
void follow_control(float distance)
{
    uint16_t speed;
    float error = FOLLOW_TARGET_DIST - distance;
    float speed_output;
    
    if (error > -FOLLOW_DEAD_ZONE && error < FOLLOW_DEAD_ZONE) {
        Car_Stop();
        follow_integral = 0;
        follow_prev_error = 0;
        return;
    }
    
    if (distance < 2.0f) {
        Car_Stop();
        return;
    }
    if (distance > 80.0f) {
        Car_Forward(FOLLOW_MAX_SPEED);
        return;
    }
    
    follow_integral += error;
    if (follow_integral > 50) follow_integral = 50;
    if (follow_integral < -50) follow_integral = -50;
    
    float derivative = error - follow_prev_error;
    follow_prev_error = error;
    
    float Kp = 0.8f;
    float Ki = 0.05f;
    float Kd = 0.15f;
    
    speed_output = Kp * error + Ki * follow_integral + Kd * derivative;
    
    if (speed_output > FOLLOW_MAX_SPEED) speed_output = FOLLOW_MAX_SPEED;
    if (speed_output < -FOLLOW_MAX_SPEED) speed_output = -FOLLOW_MAX_SPEED;
    
    if (speed_output > 10) {
        speed = (uint16_t)(FOLLOW_MIN_SPEED + speed_output);
        if (speed > FOLLOW_MAX_SPEED) speed = FOLLOW_MAX_SPEED;
        Car_Forward(speed);
    } else if (speed_output < -10) {
        speed = (uint16_t)(FOLLOW_MIN_SPEED + (-speed_output));
        if (speed > FOLLOW_MAX_SPEED) speed = FOLLOW_MAX_SPEED;
        Car_Backward(speed);
    } else {
        Car_Stop();
    }
}

/*==================== 主函数 ====================*/
int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    SysTick_Init();
    Motor_Init();
    HCSR04_Init();
    Buzzer_Init();          
    USART1_Init(57600);
    Track_Init();
    Key_Init();
    LED_Init();              // ✅ LED初始化

    Car_Stop();

    Delay_Ms(200);
    for (int i = 0; i < 5; i++) {
        HCSR04_GetDistance();
        Delay_Ms(50);
    }

    float distance;
    SystemState currentState = STATE_NORMAL;
    ObstacleAction obstAction = OBST_ACTION_IDLE;
    uint32_t obstActionStartTick = 0;
    uint8_t obstacle_cnt = 0;

    uint8_t buzzer_on = 0;
    uint32_t buzzer_stop_tick = 0;
    
    float filtered_dist = 0;

    while (1)
    {
        // ---------- 蜂鸣器处理 ----------
        if (buzzer_on && GetTick() >= buzzer_stop_tick) {
            Buzzer_Stop();
            buzzer_on = 0;
        }

        // ---------- 按键检测 ----------
        if (Key_Scan()) {
            Switch_Mode();
            Delay_Ms(200);
            continue;
        }

        // ---------- 读取距离 ----------
        distance = HCSR04_GetDistance();
        filtered_dist = filter_distance(distance);
        
        // ✅ 关键：根据专注度控制LED
        LED_Control(attention);
        
        uint8_t obstacle_detected = (distance <= 0.0f || distance < OBSTACLE_THRESHOLD_CM) ? 1 : 0;

        // ==================== 避障逻辑 ====================
        if (currentState == STATE_NORMAL)
        {
            if (obstacle_detected) {
                obstacle_cnt++;
                if (obstacle_cnt >= OBSTACLE_IN_CNT) {
                    currentState = STATE_OBSTACLE;
                    Car_Stop();

                    Buzzer_StartAlarm(BUZZER_BEEP_MS);
                    buzzer_on = 1;
                    buzzer_stop_tick = GetTick() + BUZZER_BEEP_MS;

                    obstacle_cnt = 0;
                    obstAction = OBST_ACTION_IDLE;
                    obstActionStartTick = GetTick();
                }
            } else {
                obstacle_cnt = 0;
            }

            // ==================== 模式执行 ====================
            if (currentState == STATE_NORMAL) {
                if (currentMode == MODE_LINEWALKING) {
                    app_LineWalking();
                } else {
                    follow_control(filtered_dist);
                }
            }
        }
        else // STATE_OBSTACLE
        {
            uint32_t now = GetTick();
            switch (obstAction)
            {
                case OBST_ACTION_IDLE:
                    Car_Backward(OBSTACLE_SPEED);
                    obstAction = OBST_ACTION_BACK;
                    obstActionStartTick = now;
                    break;
                case OBST_ACTION_BACK:
                    if (now - obstActionStartTick >= OBST_BACK_TIME_MS) {
                        Car_TurnRight(OBSTACLE_SPEED);
                        obstAction = OBST_ACTION_TURN;
                        obstActionStartTick = now;
                    }
                    break;
                case OBST_ACTION_TURN:
                    if (now - obstActionStartTick >= OBST_TURN_TIME_MS) {
                        Car_Forward(OBSTACLE_SPEED);
                        obstAction = OBST_ACTION_FORWARD;
                        obstActionStartTick = now;
                    }
                    break;
                case OBST_ACTION_FORWARD:
                    if (now - obstActionStartTick >= OBST_FORWARD_TIME_MS) {
                        if (!obstacle_detected) {
                            currentState = STATE_NORMAL;
                            Car_Stop();
                            if (buzzer_on) {
                                Buzzer_Stop();
                                buzzer_on = 0;
                            }
                            obstacle_cnt = 0;
                            obstAction = OBST_ACTION_IDLE;
                        } else {
                            Car_Backward(OBSTACLE_SPEED);
                            obstAction = OBST_ACTION_BACK;
                            obstActionStartTick = now;
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        Delay_Ms(50);
    }
}