#ifndef __BSP_LINEWALKING_H__
#define __BSP_LINEWALKING_H__

#include "stm32f10x.h"

// ---- 4·Ѳ�ߴ��������Ŷ��壨��������ʵ�ʽ����޸ģ� ----
#define LINE_L1_PORT    GPIOC
#define LINE_L1_PIN     GPIO_Pin_14
#define LINE_L1_RCC     RCC_APB2Periph_GPIOC

#define LINE_L2_PORT    GPIOC
#define LINE_L2_PIN     GPIO_Pin_13
#define LINE_L2_RCC     RCC_APB2Periph_GPIOC

#define LINE_R1_PORT    GPIOC
#define LINE_R1_PIN     GPIO_Pin_15
#define LINE_R1_RCC     RCC_APB2Periph_GPIOC

#define LINE_R2_PORT    GPIOB
#define LINE_R2_PIN     GPIO_Pin_12
#define LINE_R2_RCC     RCC_APB2Periph_GPIOB

void Track_Init(void);
void Track_Read(uint8_t *pL1, uint8_t *pL2, uint8_t *pR1, uint8_t *pR2);

#endif


