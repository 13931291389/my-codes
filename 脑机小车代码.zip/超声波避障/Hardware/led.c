#include "led.h"
#include "stm32f10x.h"

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    
    // ??GPIOB??
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    // ====== ??:??PB3/PB4????? ======
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);  // ??AFIO??
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);  // ??JTAG,??SWD
    
    // ??PB3?????
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
    
    // ??PB4?????
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_4;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
    
    // ????:??LED???(???)
    GPIO_SetBits(GPIOB, GPIO_Pin_3);
    GPIO_SetBits(GPIOB, GPIO_Pin_4);
}

void LED_Control(uint8_t attention)
{
    if (attention < 40)
    {
        GPIO_ResetBits(GPIOB, GPIO_Pin_3);   // PB3?
        GPIO_SetBits(GPIOB, GPIO_Pin_4);     // PB4?
    }
    else
    {
        GPIO_SetBits(GPIOB, GPIO_Pin_3);     // PB3?
        GPIO_ResetBits(GPIOB, GPIO_Pin_4);   // PB4?
    }
}