#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f10x.h"

// 初始化 SysTick，配置为每 1ms 中断一次
void SysTick_Init(void);
void DWT_Init(void);
void Delay_us(uint32_t us);
// 获取当前系统运行的毫秒数（上电开始计数，约 49 天后溢出）
uint32_t GetTick(void);

// 非阻塞延时（单位：毫秒）
// 注意：此函数会阻塞当前线程，但阻塞期间仍能响应中断
void Delay_Ms(uint32_t ms);

#endif
