#include "systick.h"

// 静态全局变量，用于记录系统运行毫秒数
static volatile uint32_t sys_tick = 0;

// SysTick 中断处理函数（1ms 调用一次）
void SysTick_Handler(void)
{
    sys_tick++;
}

// 初始化 SysTick：72MHz 系统时钟，72000 分频 -> 1kHz 中断频率（1ms 一次）
void SysTick_Init(void)
{
    // 设置 SysTick 重装载值：SystemCoreClock/1000 - 1
    // 例如 SystemCoreClock = 72MHz，则 72000000/1000 - 1 = 71999
    if (SysTick_Config(SystemCoreClock / 1000))
    {
        // 配置失败，无限循环（可添加错误处理）
        while (1);
    }
    // SysTick_Config 会自动使能中断，不需要额外设置 NVIC
}

// 获取当前系统毫秒数
uint32_t GetTick(void)
{
    return sys_tick;
}

// 阻塞延时（毫秒）
void Delay_Ms(uint32_t ms)
{
    uint32_t start = GetTick();
    while ((GetTick() - start) < ms);
}
