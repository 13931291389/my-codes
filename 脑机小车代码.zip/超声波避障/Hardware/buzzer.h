#ifndef __BUZZER_H
#define __BUZZER_H

#include "stm32f10x.h"

#define BUZZER_PORT   GPIOB
#define BUZZER_PIN    GPIO_Pin_13    // ★ 改为 PB13

// 假设蜂鸣器为低电平有效（GPIO 输出低电平时响）
#define BEEP_ON       GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN)
#define BEEP_OFF      GPIO_SetBits(BUZZER_PORT, BUZZER_PIN)

void Buzzer_Init(void);
void Buzzer_StartAlarm(uint32_t duration_ms);
void Buzzer_Update(void);
void Buzzer_Stop(void);

#endif
