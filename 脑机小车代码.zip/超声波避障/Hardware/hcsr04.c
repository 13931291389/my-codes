#include "hcsr04.h"
#include "stm32f10x.h"

// 定时器超时标志
static volatile uint8_t capture_timeout  = 0;
static volatile uint8_t capture_complete = 0;
static volatile uint16_t capture_value   = 0;

// TIM3 中断处理：包含捕获和溢出
void HCSR04_TIM3_IRQHandler(void)
{
    // 1. 捕获中断（CC1 – ECHO 引脚）
    if (TIM_GetITStatus(TIM3, TIM_IT_CC1) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);
        
        // 上升沿/下降沿处理
        if ((TIM3->CCER & TIM_CCER_CC1P) == 0)   // 当前是上升沿触发
        {
            // 记录上升沿发生，并切换为下降沿触发
            TIM3->CNT = 0;                        // 从0开始计时
            TIM3->CCER |= TIM_CCER_CC1P;          // 改为下降沿捕获
        }
        else                                      // 下降沿触发
        {
            // 记录脉宽
            capture_value = TIM_GetCapture1(TIM3);
            capture_complete = 1;
            TIM3->CCER &= ~TIM_CCER_CC1P;         // 恢复上升沿捕获
        }
    }

    // 2. 更新中断（溢出 – 用作超时）
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
        // 发生溢出，说明回波超时未完成
        capture_timeout = 1;
        // 清除可能正在进行的捕获，并恢复为上升沿等待
        TIM3->CCER &= ~TIM_CCER_CC1P;             // 确保下次是上升沿
        TIM_ITConfig(TIM3, TIM_IT_CC1, ENABLE);   // 捕获中断保持开启
    }
}

void HCSR04_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
    TIM_ICInitTypeDef TIM_ICInitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;
    
    // 时钟使能
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    
    // Trig 引脚：推挽输出
    GPIO_InitStruct.GPIO_Pin   = HCSR04_TRIG_PIN;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(HCSR04_TRIG_PORT, &GPIO_InitStruct);
    GPIO_ResetBits(HCSR04_TRIG_PORT, HCSR04_TRIG_PIN);
    
    // Echo 引脚：浮空输入
    GPIO_InitStruct.GPIO_Pin  = HCSR04_ECHO_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(HCSR04_ECHO_PORT, &GPIO_InitStruct);
    
    // 定时器基础配置：72MHz / (71+1) = 1MHz → 1us 计数
    TIM_TimeBaseStruct.TIM_Period        = 0xFFFF;   // 65535us ≈ 65.5ms 溢出
    TIM_TimeBaseStruct.TIM_Prescaler     = 71;
    TIM_TimeBaseStruct.TIM_ClockDivision = 0;
    TIM_TimeBaseStruct.TIM_CounterMode   = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStruct);
    
    // 输入捕获：通道1，上升沿触发
    TIM_ICInitStruct.TIM_Channel     = TIM_Channel_1;
    TIM_ICInitStruct.TIM_ICPolarity  = TIM_ICPolarity_Rising;
    TIM_ICInitStruct.TIM_ICSelection = TIM_ICSelection_DirectTI;
    TIM_ICInitStruct.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    TIM_ICInitStruct.TIM_ICFilter    = 0;
    TIM_ICInit(TIM3, &TIM_ICInitStruct);
    
    // 使能捕获中断 + 更新中断（用于超时）
    TIM_ITConfig(TIM3, TIM_IT_CC1 | TIM_IT_Update, ENABLE);
    
    // 中断优先级配置
    NVIC_InitStruct.NVIC_IRQChannel                   = TIM3_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority        = 0;
    NVIC_InitStruct.NVIC_IRQChannelCmd                = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
    
    // 启动定时器
    TIM_Cmd(TIM3, ENABLE);
}

float HCSR04_GetDistance(void)
{
    // 清空标志
    capture_complete = 0;
    capture_timeout  = 0;
    
    // 发送 10us 触发脉冲（使用 __NOP 大致延时，安全且不阻塞）
    GPIO_SetBits(HCSR04_TRIG_PORT, HCSR04_TRIG_PIN);
    // 大约 10us 延时（72MHz 下约为 720 个 NOP，这里用循环保证 >10us）
    for (volatile uint32_t i = 0; i < 720; i++);
    GPIO_ResetBits(HCSR04_TRIG_PORT, HCSR04_TRIG_PIN);
    
    // 等待测量完成或超时（TIM3 更新中断会置位 capture_timeout）
    uint32_t timeout_tick = 200000;  // 备份死循环超时（若中断彻底失效）
    while (!capture_complete && !capture_timeout)
    {
        if (--timeout_tick == 0) break;   // 最终保险，防止硬件错误导致死循环
    }
    
    if (capture_complete)
        return capture_value / 58.0f;     // 距离（cm）
    else
        return 0.0f;                      // 超时或错误返回 0
}
