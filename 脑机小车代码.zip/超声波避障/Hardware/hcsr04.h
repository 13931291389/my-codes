#ifndef __HCSR04_H
#define __HCSR04_H

#include "stm32f10x.h"
             
// 引脚定义（请根据实际接线修改）
#define HCSR04_TRIG_PORT   GPIOA
#define HCSR04_TRIG_PIN    GPIO_Pin_4
#define HCSR04_ECHO_PORT   GPIOA
#define HCSR04_ECHO_PIN    GPIO_Pin_6
void HCSR04_TIM3_IRQHandler(void);
void HCSR04_Init(void);
float HCSR04_GetDistance(void);   // 返回距离(cm)，失败返回0
#define OBSTACLE_THRESHOLD_CM   20.0f   // 避障距离阈值 20cm
#endif

