#include "app_linewalking.h"
#include "bsp_linewalking.h"
#include "Motor.h"
#include "Delay.h"


void app_LineWalking(void)
{
    uint8_t L1, L2, R1, R2;
    
    Track_Read(&L1, &L2, &R1, &R2);
    
   
    if (L2 == 0 && R1 == 0)
    {
        Car_Forward(400);
      
    }
   
    else if (L2==0)
    {
       Car_TurnLeft(400);
      
    }
		else if (L1==0)
    {
       Car_TurnLeft(400);
      
    }
		else if (R1==0)
    {
       Car_TurnRight(400);
        
    }
		else if (R2==0)
    {
       Car_TurnRight(400);
    }
		
    
}
