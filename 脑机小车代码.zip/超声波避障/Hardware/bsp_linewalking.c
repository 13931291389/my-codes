#include "bsp_linewalking.h"

void Track_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    // L1
    RCC_APB2PeriphClockCmd(LINE_L1_RCC, ENABLE);
    GPIO_InitStruct.GPIO_Pin = LINE_L1_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;  // ��������
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(LINE_L1_PORT, &GPIO_InitStruct);

    // L2
    RCC_APB2PeriphClockCmd(LINE_L2_RCC, ENABLE);
    GPIO_InitStruct.GPIO_Pin = LINE_L2_PIN;
    GPIO_Init(LINE_L2_PORT, &GPIO_InitStruct);

    // R1
    RCC_APB2PeriphClockCmd(LINE_R1_RCC, ENABLE);
    GPIO_InitStruct.GPIO_Pin = LINE_R1_PIN;
    GPIO_Init(LINE_R1_PORT, &GPIO_InitStruct);

    // R2
    RCC_APB2PeriphClockCmd(LINE_R2_RCC, ENABLE);
    GPIO_InitStruct.GPIO_Pin = LINE_R2_PIN;
    GPIO_Init(LINE_R2_PORT, &GPIO_InitStruct);
}

void Track_Read(uint8_t *pL1, uint8_t *pL2, uint8_t *pR1, uint8_t *pR2)
{
    *pL1 = GPIO_ReadInputDataBit(LINE_L1_PORT, LINE_L1_PIN);
    *pL2 = GPIO_ReadInputDataBit(LINE_L2_PORT, LINE_L2_PIN);
    *pR1 = GPIO_ReadInputDataBit(LINE_R1_PORT, LINE_R1_PIN);
    *pR2 = GPIO_ReadInputDataBit(LINE_R2_PORT, LINE_R2_PIN);
}

