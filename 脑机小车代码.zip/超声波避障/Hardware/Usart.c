#include "stm32f10x.h"
#include "usart.h"

int attention = 0;   // 全局注意力值

static char buf[32];
static uint8_t idx = 0;

void USART1_Init(u32 baudrate)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    USART_InitStruct.USART_BaudRate = baudrate;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStruct);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);

    NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
}

void USART1_SendByte(u8 ch)
{
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, ch);
}

void USART1_SendString(char *str)
{
    while(*str) USART1_SendByte(*str++);
}

// 手动解析三个整数（不依赖sscanf）
static void parse_line(char *s)
{
    int val[3] = {0,0,0};
    int i = 0;
    char *p = s;
    while(*p && i<3) {
        if(*p >= '0' && *p <= '9') {
            val[i] = val[i]*10 + (*p - '0');
        } else if(*p == ',') {
            i++;
        }
        p++;
    }
    if(i == 2) {  // 至少解析到三个数（i从0开始，解析完第三个后i=2）
        attention = val[0];
        // 如果需要还可以保存冥想值和信号质量，这里只取注意力
    }
}

void USART1_IRQHandler(void)
{
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        uint8_t ch = USART_ReceiveData(USART1);
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);  // 必须加！

        if(ch == '\n' || idx >= sizeof(buf)-1)
        {
            if(idx > 0)
            {
                buf[idx] = '\0';
                parse_line(buf);
                idx = 0;
            }
        }
        else if(ch != '\r')
        {
            buf[idx++] = ch;
        }
    }
}
