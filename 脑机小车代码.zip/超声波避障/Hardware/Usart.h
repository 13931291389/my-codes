#ifndef __USART_H
#define __USART_H

#include "stm32f10x.h"

void USART1_Init(u32 baudrate);
void USART1_SendByte(u8 ch);
void USART1_SendString(char *str);

// 外部变量：主函数可以直接用
extern int attention;
extern int quality;
extern int meditation;

#endif

