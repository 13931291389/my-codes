#include "buzzer.h"
#include "systick.h"

static uint8_t alarm_active = 0;
static uint32_t alarm_end_time = 0;

void Buzzer_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Pin = BUZZER_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
    
    BEEP_OFF;   // 默认关闭（高电平）
}

void Buzzer_StartAlarm(uint32_t duration_ms)
{
    alarm_active = 1;
    if (duration_ms == 0) {
        alarm_end_time = 0xFFFFFFFF;  // 无限
    } else {
        alarm_end_time = GetTick() + duration_ms;
    }
    BEEP_ON;    // 响
}

void Buzzer_Stop(void)
{
    alarm_active = 0;
    BEEP_OFF;
}

void Buzzer_Update(void)
{
    if (alarm_active && alarm_end_time != 0xFFFFFFFF && GetTick() >= alarm_end_time) {
        Buzzer_Stop();
    }
}
