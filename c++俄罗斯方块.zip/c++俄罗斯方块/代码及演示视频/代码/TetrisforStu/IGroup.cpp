// IGroup.cpp - I型方块实现
#include "IGroup.h"
#include "Common.h"

IGroup::IGroup()
{
    // I型方块：垂直一字型
    // ■
    // ■
    // ■
    // ■
    block[0].setRow(1);//位于第一行
    block[0].setCol(GAME_COL / 2);//所有的列都相同
    block[1].setRow(2);
    block[1].setCol(GAME_COL / 2);
    block[2].setRow(3);
    block[2].setCol(GAME_COL / 2);
    block[3].setRow(4);
    block[3].setCol(GAME_COL / 2);
}

void IGroup::rotate()
{
    // I型方块旋转：垂直 <-> 水平
    int centerRow = block[1].getRow();
    int centerCol = block[1].getCol();

    for (int i = 0; i < 4; i++) {
        if (i == 1) continue; // 跳过中心方块

        int row = block[i].getRow() - centerRow;
        int col = block[i].getCol() - centerCol;

        // 旋转90度
        int newRow = -col;
        int newCol = row;

        block[i].setRow(centerRow + newRow);
        block[i].setCol(centerCol + newCol);
    }
}

void IGroup::rotateBack()
{
    // I型方块只有两种状态，旋转一次即可回退
    rotate();
}
