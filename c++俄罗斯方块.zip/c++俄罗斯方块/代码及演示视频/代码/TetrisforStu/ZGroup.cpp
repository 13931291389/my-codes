// ZGroup.cpp - Z型方块实现
#include "ZGroup.h"
#include "Common.h"

ZGroup::ZGroup()
{
    // Z型方块：
    // ■ ■
    //   ■ ■
    block[0].setRow(2);
    block[0].setCol(GAME_COL / 2);
    block[1].setRow(2);
    block[1].setCol(GAME_COL / 2 + 1);
    block[2].setRow(1);
    block[2].setCol(GAME_COL / 2 - 1);
    block[3].setRow(1);
    block[3].setCol(GAME_COL / 2);
}

void ZGroup::rotate()
{
    int centerRow = block[0].getRow();
    int centerCol = block[0].getCol();

    for (int i = 0; i < 4; i++) {
        if (i == 0) continue;

        int row = block[i].getRow() - centerRow;
        int col = block[i].getCol() - centerCol;

        int newRow = -col;
        int newCol = row;

        block[i].setRow(centerRow + newRow);
        block[i].setCol(centerCol + newCol);
    }
}

void ZGroup::rotateBack()
{
    rotate();
}
