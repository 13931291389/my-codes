﻿// OGroup.cpp
#include "OGroup.h"
#include "Common.h" 

OGroup::OGroup()
{
    block[0].setRow(2);
    block[0].setCol(GAME_COL / 2 - 1);
    block[1].setRow(2);
    block[1].setCol(GAME_COL / 2);
    block[2].setRow(1);
    block[2].setCol(GAME_COL / 2);
    block[3].setRow(1);
    block[3].setCol(GAME_COL / 2 - 1);
}

void OGroup::rotate()
{
    // O形方块旋转后形状不变，所以什么都不做
}

void OGroup::rotateBack()
{
    // O形方块旋转后形状不变，所以什么都不做
}