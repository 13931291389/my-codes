﻿#include "Block.h"

Block::Block()
{
}

Block::Block(int r, int c, char b)
{
	this->row = r;//设置行坐标
	this->col = c;//设置列坐标
	this->background = b; //设置显示字符
}
//设置行坐标
void Block::setRow(int r)
{
	this->row = r;
}
//获取行坐标
int Block::getRow()
{
	return this->row;
}

void Block::setCol(int col)
{
	this->col = col;
}

int Block::getCol()
{
	return this->col;
}

void Block::setBackground(char b)
{
	this->background = b;
}

char Block::getBackground()
{
	return this->background;
}

void Block::move(int r, int c)
{
	this->row += r;//行坐标变化
	this->col += c;//列坐标变化
}
