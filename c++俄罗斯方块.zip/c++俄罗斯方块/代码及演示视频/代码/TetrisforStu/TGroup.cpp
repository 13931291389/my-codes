// TGroup.cpp - T型方块实现
#include "TGroup.h"
#include "Common.h"

TGroup::TGroup()
{
    // T型方块：
    // ■ ■ ■
    //   ■
    block[0].setRow(1);
    block[0].setCol(GAME_COL / 2 - 1);
    block[1].setRow(1);
    block[1].setCol(GAME_COL / 2);
    block[2].setRow(1);
    block[2].setCol(GAME_COL / 2 + 1);
    block[3].setRow(2);
    block[3].setCol(GAME_COL / 2);
}

void TGroup::rotate()
{
    int centerRow = block[1].getRow();
    int centerCol = block[1].getCol();

    for (int i = 0; i < 4; i++) {
        if (i == 1) continue;

        int row = block[i].getRow() - centerRow;
        int col = block[i].getCol() - centerCol;

        int newRow = -col;
        int newCol = row;

        block[i].setRow(centerRow + newRow);
        block[i].setCol(centerCol + newCol);
    }
}

void TGroup::rotateBack()
{
    rotate();
    rotate();
    rotate();
}
