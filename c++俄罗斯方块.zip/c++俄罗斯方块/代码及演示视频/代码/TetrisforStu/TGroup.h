// TGroup.h - T型方块
#ifndef TGROUP_H
#define TGROUP_H
#include "Group.h"

class TGroup : public Group
{
public:
    TGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif
