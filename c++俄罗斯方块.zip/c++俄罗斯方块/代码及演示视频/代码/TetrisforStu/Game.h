﻿#ifndef GAME_H
#define GAME_H
#include "GameBoard.h"    //后台数据 
#include "GameUI.h"		  //前台界面 

class Game
{
private:
	GameBoard* gameBoard;     //后台数据
	GameUI* gameUI;			  //前台UI 
	Group* pGroup;			  //方块 
	int score;				  //得分 
	bool gameOver;			  //游戏结束标志
public:
	Game();				//构造函数 
	~Game();			//析构函数 
	void gameStart();	//游戏开始 
	void gameTetris();	//俄罗斯方块游戏 
	void gameEnd();		//游戏结束 
	void createGroup();	//随机产生Block 
	void insertIntoBoard();	//该方块到底，不能在移动。 
	bool checkGameOver();	//检查游戏是否结束
};

#endif
