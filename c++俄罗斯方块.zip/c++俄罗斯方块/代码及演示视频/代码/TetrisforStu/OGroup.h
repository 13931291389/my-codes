﻿// OGroup.h
#ifndef OGRUOP_H
#define OGRUOP_H
#include "Group.h"

class OGroup : public Group
{
public:
    OGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif