﻿#include "GameBoard.h"

GameBoard::GameBoard()
{
	// 初始化棋盘 
	this->board = new int*[GAME_ROW];
	
	for(int row=0; row<GAME_ROW; row++)//遍历每一行
	{
		this->board[row] = new int[GAME_COL];//动态分配指针
		
		for(int col=0; col<GAME_COL; col++) //初始化每个格子
		{
			if(row == 0 || row == GAME_ROW-1 || col == 0 || col == GAME_COL-1)
			{
				board[row][col] = BORDER;
			}else {
				board[row][col] = EMPTY;
			}
		}
	}
}

int GameBoard::removeRow()//消除功能
{
	int rowCount = 0;

	for (int row = GAME_ROW - 2; row > 0; row--)
	{
		bool isFull = true;
		// 检查该行是否已满
		for (int col = 1; col < GAME_COL - 1; col++)
		{
			if (board[row][col] == EMPTY)
			{
				isFull = false;
				break;
			}
		}

		if (isFull)
		{
			// 消除该行并让上面的行下落
			for (int r = row; r > 1; r--)
			{
				for (int col = 1; col < GAME_COL - 1; col++)
				{
					board[r][col] = board[r - 1][col];
				}
			}
			// 清空最顶行
			for (int col = 1; col < GAME_COL - 1; col++)
			{
				board[1][col] = EMPTY;
			}
			rowCount++;
			// 由于上面的行下落了，需要重新检查当前行
			row++;
		}
	}

	return rowCount;
}
void GameBoard::downRow(int row)
{
	for(int r=row; r>0; r--)
		for(int col=1; col<GAME_COL-1; col++) 
			board[r][col] = board[r-1][col];
	for(int col=1; col<GAME_COL-1; col++)
		board[1][col] = EMPTY;                            //首行清0 
}

int ** GameBoard::getBoard()
{
	return board;
}

void GameBoard::combineGroup(Group *group)
{
	int row;
	int col;
	
	for(int i=0; i<4; i++)
	{
		row = (group->getBlock())[i].getRow();
		col = (group->getBlock())[i].getCol();
		
		if(row>-1 && row<GAME_ROW && col>-1 && col<GAME_COL)
			board[row][col]=BLOCK;
	}	
} 

void GameBoard::removeGroup(Group *group)//消除
{
	int row;
	int col;
	
	for(int i=0; i<4; i++)//遍历四个小方块
	{
		row = (group->getBlock())[i].getRow();//获取坐标
		col = (group->getBlock())[i].getCol();
		//检测是否在有效范围内
		if(row>-1 && row<GAME_ROW && col>-1 && col<GAME_COL)
			if(row == 0)
				board[row][col]=BORDER;
			else
				board[row][col]=EMPTY;//顶部清空
	}
}

bool GameBoard::determine(Group *group)//判断方块位置是否合法
{
	int row;
	int col;
	
	for(int i=0; i<4; i++)//遍历
	{
		row = (group->getBlock())[i].getRow();//获取
		col = (group->getBlock())[i].getCol();
		
		// 允许方块在负数行（屏幕上方）存在，只检查列边界
		if(col < 0 || col >= GAME_COL)
		{
			return false;  // 超出左右边界
		}
		
		// 如果方块还在屏幕上方（负数行），跳过检查
		if(row < 0)
		{
			continue;
		}
		
		// 检查是否超出下边界
		if(row >= GAME_ROW)
		{
			return false;
		}
		
		// 检查位置是否已被占用或是边界
		if(board[row][col] != EMPTY)
		{
			return false;
		}
	}
	
	return true;
} 
