﻿#ifndef GROUP_H
#define GROUP_H
#include "Block.h"

//"田"字型方块
 
class Group
{
protected:
	Block block[4];   //俄罗斯方块每个都有4个方块组成

public:
	virtual void moveLeft();			//向左移动 
	virtual void moveRight();			//向右移动 
	virtual void moveDown();			//下落 
	virtual void moveUp();				//上升 
	virtual void rotate()=0; 			//旋转 
	virtual void rotateBack()=0;
	virtual Block* getBlock();			//获得Block 
	virtual bool getStatus();			//判断Group是否在最顶端；true-在最顶端，false-不在最顶端 
};

#endif
