﻿// LGroup.cpp - 替代方案（更简洁）
#include "LGroup.h"
#include "Common.h"

LGroup::LGroup()
{
    // L型方块：
    // ■
    // ■
    // ■ ■
    block[0].setRow(3);
    block[0].setCol(GAME_COL / 2);
    block[1].setRow(2);
    block[1].setCol(GAME_COL / 2);
    block[2].setRow(1);
    block[2].setCol(GAME_COL / 2);
    block[3].setRow(3);
    block[3].setCol(GAME_COL / 2 + 1);
}

void LGroup::rotate()
{
    int centerRow = block[1].getRow(); // 以第二个方块为旋转中心
    int centerCol = block[1].getCol();

    // 对每个方块应用旋转矩阵 [0 -1; 1 0] 进行90度旋转
    for (int i = 0; i < 4; i++) {
        if (i == 1) continue; // 跳过中心方块

        int row = block[i].getRow() - centerRow;
        int col = block[i].getCol() - centerCol;

        // 应用旋转矩阵：新位置 = [0 -1; 1 0] * [row; col]
        int newRow = -col;
        int newCol = row;

        block[i].setRow(centerRow + newRow);
        block[i].setCol(centerCol + newCol);
    }
}

void LGroup::rotateBack()
{
    // 连续旋转3次相当于回退1次
    rotate();
    rotate();
    rotate();
}