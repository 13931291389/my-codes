﻿#include "Game.h"
#include "OGroup.h"
#include "LGroup.h"
#include "IGroup.h"
#include "JGroup.h"
#include "SGroup.h"
#include "TGroup.h"
#include "ZGroup.h"
#include<iostream>
#include<stdlib.h>  //调用windows清屏命令 
#include<conio.h>	//捕捉按键中断 
#include<cstdlib>	//随机数函数 
#include<time.h>	//time()时间戳函数 
#include<windows.h> //延时函数
#include<random>    //C++11随机数生成器 

Game::Game()
{
	this->gameBoard = new GameBoard();//分配
	this->gameUI = new GameUI();
	this->pGroup = nullptr;		
	score = 0;					//初始化为0分 
	gameOver = false;			//游戏未结束
}

Game::~Game()
{
	delete this->gameBoard;		//释放空间 
	delete this->gameUI;		//释放空间 
	if (pGroup != nullptr) {   
		delete pGroup;
		pGroup = nullptr;
	}
}

void Game::gameStart()
{
	int key;
	while (1)
	{
		system("cls");					 //清屏命令 
		this->gameUI->GameSartUI();  	//显示启动页面
		std::cin >> key;     		 	//获取键盘输入 

		switch (key)
		{
		case 1:
			this->gameTetris();	 	//进入俄罗斯方块游戏 
			break;
		case 2:
			exit(0);				//退出程序，0--代表正常退出 
			break;
		default:
			break;
		};
	}
}



void Game::gameTetris()
{
	int key;
	system("cls");
	gameOver = false;
	score = 0; // 重置分数
	
	// 隐藏光标减少闪烁
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO cursorInfo;
	GetConsoleCursorInfo(hConsole, &cursorInfo);
	cursorInfo.bVisible = FALSE;
	SetConsoleCursorInfo(hConsole, &cursorInfo);
	
	createGroup();//创建第一个方块

	while (!gameOver)
	{
		gameBoard->combineGroup(pGroup);// 步骤1：将方块合并到游戏板

		// 使用system("cls")清屏
		system("cls");
		gameUI->TetirsUI(gameBoard->getBoard(), score);
		gameBoard->removeGroup(pGroup); //从游戏板移除方块（为移动做准备）

		fflush(stdin);// 清空输入缓冲区
		if (_kbhit())// 检查是否有按键按下
		{
			key = _getch(); // 获取按键字符
			switch (key)
			{
			case 'w':
			case 'W':
				pGroup->rotate();// 多态调用实际调用IGroup::rotate()
				if (!gameBoard->determine(pGroup))
					pGroup->rotateBack();// 多态调用实际调用IGroup::rotate()
				break;
			case 's':
			case 'S':
				insertIntoBoard();
				break;
			case 'a':
			case 'A':
				pGroup->moveLeft();
				if (!gameBoard->determine(pGroup))
					pGroup->moveRight();
				break;
			case 'd':
			case 'D':
				pGroup->moveRight();
				if (!gameBoard->determine(pGroup))
					pGroup->moveLeft();
				break;
			default:
				break;
			}
		}
		else {
			insertIntoBoard();
			Sleep(500);
		}
	}
	
	// 恢复光标显示
	cursorInfo.bVisible = TRUE;
	SetConsoleCursorInfo(hConsole, &cursorInfo);

	// 游戏结束显示
	if (gameOver) {
		system("cls");
		std::cout << "*************************************" << std::endl;
		std::cout << "          " << "Game Over!" << std::endl;
		std::cout << "          " << "Your Score: " << score << std::endl;
		std::cout << "          " << "Press any key to return to menu..." << std::endl;
		std::cout << "*************************************" << std::endl;
		_getch();
	}
}
void Game::createGroup()
{
	// 使用C++11的随机数生成器，比rand()更可靠
	static std::random_device rd;  // 真随机数种子
	static std::mt19937 gen(rd()); // Mersenne Twister 随机数引擎
	static std::uniform_int_distribution<> dis(1, BLOCKNUMBER); // 均匀分布 1-7
	
	// 产生1-7之间的随机数
	int blockRand = dis(gen);
	
	// 根据随机数创建对应的方块
	switch (blockRand)
	{
	case 1:
		pGroup = new IGroup();  // I型方块
		break;
	case 2:
		pGroup = new JGroup();  // J型方块
		break;
	case 3:
		pGroup = new LGroup();  // L型方块
		break;
	case 4:
		pGroup = new OGroup();  // O型方块
		break;
	case 5:
		pGroup = new SGroup();  // S型方块
		break;
	case 6:
		pGroup = new TGroup();  // T型方块
		break;
	case 7:
		pGroup = new ZGroup();  // Z型方块
		break;
	default:
		pGroup = new OGroup();  // 默认O型方块
		break;
	}
}

void Game::insertIntoBoard()//积分
{
	pGroup->moveDown();                 // 方块下落 
	if (!gameBoard->determine(pGroup))   // 如果判断不可以下落
	{
		pGroup->moveUp();               // 方块上升回去 
		gameBoard->combineGroup(pGroup);// 把方块并入board 

		// 修改计分逻辑
		int lines = gameBoard->removeRow();
		if (lines > 0) {
			switch (lines) {
			case 1: score += 100; break;
			case 2: score += 300; break;
			case 3: score += 500; break;
			case 4: score += 800; break;
			}
		}

		// BUG修复7: 释放旧方块内存，避免内存泄漏
		delete pGroup;
		pGroup = nullptr;

		// 创建新方块前检查游戏是否结束
		createGroup();

		// 检查新方块是否可以放置，如果不能则游戏结束
		if (!gameBoard->determine(pGroup)) {
			gameOver = true;
		}
	}
}

bool Game::checkGameOver()
{
	// 遍历四个小方块
	for (int i = 0; i < 4; i++)
	{//获取当前坐标
		int row = (pGroup->getBlock())[i].getRow();
		int col = (pGroup->getBlock())[i].getCol();

		// 检测坐标是否在游戏区域内
		if (row >= 0 && row < GAME_ROW && col >= 0 && col < GAME_COL) {
			if (gameBoard->getBoard()[row][col] == BLOCK) {
				return true;
			}
		}
	}
	return false;
}