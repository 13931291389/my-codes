﻿#include "GameUI.h"
#include <iostream>
#include <string>
#include "Common.h"

GameUI::GameUI()
{
}

GameUI::~GameUI()
{
}

void GameUI::GameSartUI()
{
	std::cout << "╔═══════════════════════════════════════════╗" << std::endl;
	std::cout << "║                                           ║" << std::endl;
	std::cout << "║        ████████╗███████╗████████╗        ║" << std::endl;
	std::cout << "║        ╚══██╔══╝██╔════╝╚══██╔══╝        ║" << std::endl;
	std::cout << "║           ██║   █████╗     ██║           ║" << std::endl;
	std::cout << "║           ██║   ██╔══╝     ██║           ║" << std::endl;
	std::cout << "║           ██║   ███████╗   ██║           ║" << std::endl;
	std::cout << "║           ╚═╝   ╚══════╝   ╚═╝           ║" << std::endl;
	std::cout << "║                                           ║" << std::endl;
	std::cout << "║        ██████╗ ██╗███████╗               ║" << std::endl;
	std::cout << "║        ██╔══██╗██║██╔════╝               ║" << std::endl;
	std::cout << "║        ██████╔╝██║███████╗               ║" << std::endl;
	std::cout << "║        ██╔══██╗██║╚════██║               ║" << std::endl;
	std::cout << "║        ██║  ██║██║███████║               ║" << std::endl;
	std::cout << "║        ╚═╝  ╚═╝╚═╝╚══════╝               ║" << std::endl;
	std::cout << "║                                           ║" << std::endl;
	std::cout << "╠═══════════════════════════════════════════╣" << std::endl;
	std::cout << "║                                           ║" << std::endl;
	std::cout << "║          【1】 开始游戏 (Start)           ║" << std::endl;
	std::cout << "║          【2】 退出游戏 (Quit)            ║" << std::endl;
	std::cout << "║                                           ║" << std::endl;
	std::cout << "╠═══════════════════════════════════════════╣" << std::endl;
	std::cout << "║  操作说明：                               ║" << std::endl;
	std::cout << "║  W/↑ - 旋转   A/← - 左移   D/→ - 右移    ║" << std::endl;
	std::cout << "║  S/↓ - 快速下落                           ║" << std::endl;
	std::cout << "║                                           ║" << std::endl;
	std::cout << "╚═══════════════════════════════════════════╝" << std::endl;
	std::cout << std::endl;
	std::cout << "请输入选项: ";
} 

void GameUI::TetirsUI(int ** board, int score)
{
	// 使用字符串缓冲，一次性输出所有内容减少闪烁
	std::string buffer;
	buffer.reserve(2000); // 预分配空间
	
	// 顶部信息栏
	buffer += "╔═══════════════════════════════════════════════════════════╗\n";
	buffer += "║  俄罗斯方块 TETRIS                    得分: ";
	
	// 将分数转换为字符串
	std::string scoreStr = std::to_string(score);
	buffer += scoreStr;
	
	// 补齐空格使对齐 (总共需要18个字符的空间)
	int scoreDigits = scoreStr.length();
	for (int i = 0; i < 18 - scoreDigits; i++) {
		buffer += " ";
	}
	buffer += "║\n";
	buffer += "╠═══════════════════════════════════════════════════════════╣\n";
	
	// 游戏区域
	for(int row=0; row<GAME_ROW; row++)
	{
		buffer += "║ ";
		for(int col=0; col<GAME_COL; col++)
		{
			switch(board[row][col])
			{
				case BORDER:
					buffer += GAMEBORDER;
					break;
				case BLOCK:
					buffer += GAMEBLOCK;
					break;
				case EMPTY:
					buffer += GAMEEMPTY;
					break;
				default:
					break; 
			}
		}
		buffer += " ║\n";
	}
	
	// 底部信息栏
	buffer += "╠═══════════════════════════════════════════════════════════╣\n";
	buffer += "║  操作: W-旋转  A-左移  D-右移  S-快速下落                ║\n";
	buffer += "╚═══════════════════════════════════════════════════════════╝\n";
	
	// 一次性输出所有内容
	std::cout << buffer;
}
