﻿// LGroup.h
#ifndef LGROUP_H
#define LGROUP_H
#include "Group.h"

class LGroup : public Group
{
public:
    LGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif