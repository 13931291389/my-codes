// ZGroup.h - Z型方块
#ifndef ZGROUP_H
#define ZGROUP_H
#include "Group.h"

class ZGroup : public Group
{
public:
    ZGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif
