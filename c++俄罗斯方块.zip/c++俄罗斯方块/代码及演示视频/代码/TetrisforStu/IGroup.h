// IGroup.h - I型方块（一字型）
#ifndef IGROUP_H
#define IGROUP_H
#include "Group.h"

class IGroup : public Group
{
public:
    IGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif
