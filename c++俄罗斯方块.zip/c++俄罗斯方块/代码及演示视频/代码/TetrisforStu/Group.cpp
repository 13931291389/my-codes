﻿#include "Group.h"

void Group::moveLeft()
{
	for(int i=0; i<4; i++)
	{
		block[i].move(0, -1);//所有方块列坐标-1
	}
}

void Group::moveRight()
{
	for(int i=0; i<4; i++)
	{
		block[i].move(0, 1);//所有方块列坐标+1
	}
}

void Group::moveDown()
{
	for(int i=0; i<4; i++)
	{
		block[i].move(1, 0);//所有方块行坐标+1
	}
}

void Group::moveUp()//没有绑定按键，用户无法自主操控方块上移。
{
	for(int i=0; i<4; i++)
	{
		block[i].move(-1, 0);//下落碰撞时，将方块退回合法位置，防止非法碰撞
	}
} 

Block* Group::getBlock()
{
	return block;//获取方块数组指针
}

bool Group::getStatus()
{
	for(int i=0; i<4; i++)
	{
		if(block[i].getRow() <= 0)
			return true;//有方块达到顶部
	}
	
	return false;
} 
