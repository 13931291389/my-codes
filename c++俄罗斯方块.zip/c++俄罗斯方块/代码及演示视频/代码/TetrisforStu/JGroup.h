// JGroup.h - J型方块
#ifndef JGROUP_H
#define JGROUP_H
#include "Group.h"

class JGroup : public Group
{
public:
    JGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif
