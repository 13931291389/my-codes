// SGroup.h - S型方块
#ifndef SGROUP_H
#define SGROUP_H
#include "Group.h"

class SGroup : public Group
{
public:
    SGroup();
    virtual void rotate();           // 旋转
    virtual void rotateBack();       // 旋转回退
};

#endif
