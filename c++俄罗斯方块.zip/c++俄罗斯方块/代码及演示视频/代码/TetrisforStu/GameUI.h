﻿#ifndef GAMEUI_H
#define GAMEUI_H

class GameUI
{
public:
	GameUI();
	~GameUI();
	void GameSartUI();							//启动UI 
	void TetirsUI(int ** board, int score);		//俄罗斯方块UI 
};

#endif
