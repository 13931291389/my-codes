﻿#ifndef BLOCK_H
#define BLOCK_H

class Block
{
private:
	int row;  //行坐标，必有属性 
	int col;  //列坐标，必有属性 
	char background; //背景图片，可选属性
	
public:
	Block();
	Block(int r, int c, char b='*');
	
	void setRow(int r);  //写row成员变量 
	int getRow();		 //读row成员变量 
	void setCol(int c);
	int getCol();
	void setBackground(char b);//可选函数，依据可选变量background
	char getBackground();      //可选函数，依据可选变量background
	
	void move(int r, int c);   //移动 左-右+ 上-下+ 
};

#endif
