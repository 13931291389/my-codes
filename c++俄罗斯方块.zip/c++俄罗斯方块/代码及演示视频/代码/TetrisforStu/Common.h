﻿#ifndef COMMON_H
#define COMMON_H

// 使用const常量替代#define宏定义
const int GAME_ROW = 25;        // 俄罗斯方块的行
const int GAME_COL = 15;        // 俄罗斯方块的列
const int EMPTY = 0;            // 俄罗斯方块的位置为空
const int BLOCK = 1;            // 俄罗斯方块的位置已有方块
const int BORDER = 2;           // 俄罗斯方块的边界
const char GAMEEMPTY = ' ';     // 游戏EMPTY
const char GAMEBORDER = 'I';    // 游戏边框
const char GAMEBLOCK = 'O';     // 游戏方块
const int BLOCKNUMBER = 7;      // block数量（I、J、L、O、S、T、Z）

#endif
