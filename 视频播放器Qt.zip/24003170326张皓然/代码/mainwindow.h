#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QTimer>
#include <QPushButton>
#include <QSlider>
#include <QUrl>
#include <QFileInfo>
#include <QLabel>
#include <QVBoxLayout>
#include <QGraphicsView>
#include "playlistmanager.h"
#include "audiovisualizer.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void resizeEvent(QResizeEvent *event) override;
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dropEvent(QDropEvent *event) override;
    bool eventFilter(QObject *obj, QEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;

private slots:
    void onOpenFile();
    void onOpenFolder();
    void onClearPlaylist();
    void onLoadPlaylist();
    void onSavePlaylist();
    void onPlay();
    void onPause();
    void onStop();
    void onPrevious();
    void onNext();
    void onVolumeChanged(int value);
    void onPositionChanged(qint64 position);
    void onDurationChanged(qint64 duration);
    void onSeek(int value);
    void onChangePlaybackMode();
    void onMediaChanged(const QUrl &content);
    void onPlaybackStateChanged(QMediaPlayer::PlaybackState state);
    void onFullscreen();
    void onPlaylistDoubleClicked(const QModelIndex &index);
    void onPlaylistContextMenu(const QPoint &pos);
    void onPlaylistChanged();
    void onImageTimerTimeout();
    void onMediaStatusChanged(QMediaPlayer::MediaStatus status);
    void onPlaylistOrderChanged();
private:
    void setupUI();
    void setupPlayer();
    void setupPlaylistView();
    void setupConnections();
    void setupMenuBar();
    void setupDateTimeDisplay();
    void setupVolumeButton();
    void setupShortcuts();
    void updatePlayPauseButton(bool isPlaying);
    void updatePlaylistModel();
    void updateVolumeIcon(int volume);
    void showImage(const QString &imagePath);
    void hideImage();
    bool isImageFile(const QString &filePath);
    bool isVideoFile(const QString &filePath);
    bool isAudioFile(const QString &filePath);
    void addMediaFiles(const QStringList &filePaths);
    void enterFullscreen();
    void exitFullscreen();
private:
    Ui::MainWindow *ui;
    QMediaPlayer *m_player;
    QVideoWidget *m_videoWidget;
    PlaylistManager *m_playlistManager;
    QGraphicsScene *m_imageScene;
    QGraphicsPixmapItem *m_imageItem;
    QTimer *m_imageTimer;
    QPushButton *m_volumeButton;
    int m_lastVolume;
    bool m_isPlaying;
    bool m_isFullscreen;
    bool m_isImagePlaying;
    int m_imageDisplayDuration;
    // 全屏窗口相关成员变量
    QWidget *m_fullscreenWidget;
    QVBoxLayout *m_fullscreenLayout;
    QVideoWidget *m_fullscreenVideo;
    QGraphicsView *m_fullscreenView;
    QSlider *m_fullscreenSlider;
    QLabel *m_fullscreenTimeLabel;
    QLabel *m_fullscreenTotalLabel;
private slots:
    void setPlaybackSpeed(double speed);  // 新增

private:
    double m_currentSpeed;  // 当前播放速度
    QAction *m_speedAction;  // 速度菜单


};


#endif