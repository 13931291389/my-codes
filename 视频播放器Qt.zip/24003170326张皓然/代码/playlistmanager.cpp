#include "playlistmanager.h"
#include <QFileInfo>
#include <QFile>
#include <QTextStream>
#include <QRandomGenerator>

PlaylistManager::PlaylistManager(QObject *parent)
    : QObject(parent)
    , m_player(nullptr)
    , m_currentIndex(-1)
    , m_currentMode(Loop)
{
    m_player = new QMediaPlayer(this);
}

PlaylistManager::~PlaylistManager()
{
}

void PlaylistManager::addMedia(const QString &filePath)
{
    m_playlist.append(QUrl::fromLocalFile(filePath));
    emit playlistChanged();
}

void PlaylistManager::addMedias(const QStringList &filePaths)
{
    for (const QString &path : filePaths) {
        m_playlist.append(QUrl::fromLocalFile(path));
    }
    emit playlistChanged();
}

void PlaylistManager::removeMedia(int index)
{
    if (index >= 0 && index < m_playlist.size()) {
        m_playlist.removeAt(index);
        if (m_currentIndex >= m_playlist.size()) {
            m_currentIndex = m_playlist.size() - 1;
        }
        emit playlistChanged();
    }
}

void PlaylistManager::clearPlaylist()
{
    m_playlist.clear();
    m_currentIndex = -1;
    emit playlistChanged();
}

QString PlaylistManager::getMediaTitle(int index) const
{
    if (index >= 0 && index < m_playlist.size()) {
        QString path = m_playlist.at(index).toLocalFile();
        QFileInfo info(path);
        return info.baseName();
    }
    return QString();
}

void PlaylistManager::setPlaybackMode(PlaybackMode mode)
{
    m_currentMode = mode;
    emit modeChanged(getPlaybackModeText());
}

QString PlaylistManager::getPlaybackModeText() const
{
    switch (m_currentMode) {
    case CurrentItemOnce: return "播放一次";
    case CurrentItemLoop: return "单曲循环";
    case Sequential: return "顺序播放";
    case Loop: return "列表循环";
    case Random: return "随机播放";
    default: return "列表循环";
    }
}

void PlaylistManager::playNext()
{
    if (m_playlist.isEmpty()) return;

    int nextIndex = getNextIndex();
    if (nextIndex >= 0 && nextIndex < m_playlist.size()) {
        m_currentIndex = nextIndex;
        updatePlayer();
        emit currentIndexChanged(m_currentIndex);
    }
}

void PlaylistManager::playPrevious()
{
    if (m_playlist.isEmpty()) return;

    int prevIndex = m_currentIndex - 1;
    if (prevIndex < 0) {
        if (m_currentMode == Loop || m_currentMode == Sequential) {
            prevIndex = m_playlist.size() - 1;
        } else {
            prevIndex = 0;
        }
    }

    if (prevIndex >= 0 && prevIndex < m_playlist.size()) {
        m_currentIndex = prevIndex;
        updatePlayer();
        emit currentIndexChanged(m_currentIndex);
    }
}

void PlaylistManager::playCurrent()
{
    if (m_currentIndex >= 0 && m_currentIndex < m_playlist.size()) {
        updatePlayer();
    }
}

void PlaylistManager::setCurrentIndex(int index)
{
    if (index >= 0 && index < m_playlist.size()) {
        m_currentIndex = index;
        updatePlayer();
        emit currentIndexChanged(m_currentIndex);
    }
}

void PlaylistManager::updatePlayer()
{
    if (m_currentIndex >= 0 && m_currentIndex < m_playlist.size()) {
        m_player->setSource(m_playlist.at(m_currentIndex));
    }
}

int PlaylistManager::getNextIndex()
{
    switch (m_currentMode) {
    case CurrentItemOnce:
        return m_currentIndex;

    case CurrentItemLoop:
        return m_currentIndex;

    case Sequential:
        if (m_currentIndex + 1 >= m_playlist.size()) {
            return -1;
        }
        return m_currentIndex + 1;

    case Loop:
        return (m_currentIndex + 1) % m_playlist.size();

    case Random:
        return QRandomGenerator::global()->bounded(m_playlist.size());

    default:
        return (m_currentIndex + 1) % m_playlist.size();
    }
}

bool PlaylistManager::loadPlaylist(const QString &filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) return false;

    clearPlaylist();
    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (!line.isEmpty() && QFile::exists(line)) {
            addMedia(line);
        }
    }
    return true;
}

bool PlaylistManager::savePlaylist(const QString &filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) return false;

    QTextStream out(&file);
    for (const QUrl &url : m_playlist) {
        out << url.toLocalFile() << "\n";
    }
    return true;
}