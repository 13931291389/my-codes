#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QAudioOutput>
#include <QFileDialog>
#include <QMessageBox>
#include <QMenuBar>
#include <QStatusBar>
#include <QLabel>
#include <QListWidget>
#include <QDragEnterEvent>
#include <QMimeData>
#include <QDirIterator>
#include <QStandardPaths>
#include <QDateTime>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QMediaDevices>
#include <QShortcut>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QKeyEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_player(nullptr)
    , m_videoWidget(nullptr)
    , m_playlistManager(nullptr)
    , m_imageScene(nullptr)
    , m_imageItem(nullptr)
    , m_imageTimer(nullptr)
    , m_volumeButton(nullptr)
    , m_lastVolume(70)
    , m_isPlaying(false)
    , m_isFullscreen(false)
    , m_isImagePlaying(false)
    , m_imageDisplayDuration(5000)
    , m_fullscreenWidget(nullptr)
    , m_fullscreenLayout(nullptr)
    , m_fullscreenVideo(nullptr)
    , m_fullscreenView(nullptr)
    , m_fullscreenSlider(nullptr)
    , m_fullscreenTimeLabel(nullptr)
    , m_fullscreenTotalLabel(nullptr)
    , m_currentSpeed(1.0)
{
    ui->setupUi(this);

    setupUI();
    setupPlayer();
    setupPlaylistView();
    setupMenuBar();
    setupDateTimeDisplay();
    setupVolumeButton();
    setupConnections();

    setWindowTitle("轮播展示播放器 v1.0");
    setMinimumSize(900, 600);
    setAcceptDrops(true);

    m_imageTimer = new QTimer(this);
    m_imageTimer->setSingleShot(true);
    connect(m_imageTimer, &QTimer::timeout, this, &MainWindow::onImageTimerTimeout);

    statusBar()->showMessage("轮播展示播放器已启动", 3000);
}

MainWindow::~MainWindow()
{
    if (m_player) m_player->stop();
    delete ui;
    if (m_fullscreenWidget) delete m_fullscreenWidget;
}

void MainWindow::setupUI()
{
    m_videoWidget = new QVideoWidget(this);
    m_videoWidget->setStyleSheet("background-color: black;");
    m_videoWidget->setVisible(false);
    m_videoWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QVBoxLayout *layout = new QVBoxLayout(ui->graphicsView);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->addWidget(m_videoWidget);
    ui->graphicsView->setLayout(layout);

    m_imageScene = new QGraphicsScene(this);
    ui->graphicsView->setScene(m_imageScene);
    ui->graphicsView->setStyleSheet("background-color: black;");
    ui->graphicsView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    ui->progressSlider->setRange(0, 100);
    ui->progressSlider->setValue(0);

    // 确保音量标签可见
    ui->volumeLabel->setVisible(true);
    ui->volumeLabel->setText("70%");
    ui->volumeLabel->setStyleSheet("QLabel { color: white; font-size: 12px; min-width: 35px; }");

    // 设置布局拉伸因子
    QWidget *central = centralWidget();
    QVBoxLayout *mainLayout = qobject_cast<QVBoxLayout*>(central->layout());
    if (mainLayout) {
        QHBoxLayout *contentLayout = qobject_cast<QHBoxLayout*>(mainLayout->itemAt(1)->layout());
        if (contentLayout) {
            contentLayout->setStretchFactor(ui->graphicsView, 7);
            contentLayout->setStretchFactor(ui->playlistWidget, 3);
        }
    }

    // 创建全屏窗口
    m_fullscreenWidget = new QWidget();
    m_fullscreenWidget->setStyleSheet("background-color: black;");
    m_fullscreenLayout = new QVBoxLayout(m_fullscreenWidget);
    m_fullscreenLayout->setContentsMargins(0, 0, 0, 0);
    m_fullscreenLayout->setSpacing(0);

    // 创建全屏视频控件
    m_fullscreenVideo = new QVideoWidget(m_fullscreenWidget);
    m_fullscreenVideo->setStyleSheet("background-color: black;");
    m_fullscreenVideo->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    // 创建全屏图片控件
    m_fullscreenView = new QGraphicsView(m_fullscreenWidget);
    m_fullscreenView->setStyleSheet("background-color: black;");
    m_fullscreenView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_fullscreenView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_fullscreenView->setVisible(false);
    m_fullscreenView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    // 创建全屏进度条
    m_fullscreenSlider = new QSlider(Qt::Horizontal, m_fullscreenWidget);
    m_fullscreenSlider->setRange(0, 100);
    m_fullscreenSlider->setVisible(false);
    m_fullscreenSlider->setStyleSheet(
        "QSlider::groove:horizontal { height: 4px; background: #3d3d3d; border-radius: 2px; }"
        "QSlider::sub-page:horizontal { background: #4CAF50; border-radius: 2px; }"
        "QSlider::handle:horizontal { background: white; width: 12px; height: 12px; margin: -4px 0; border-radius: 6px; }"
        );

    // 创建全屏时间标签
    m_fullscreenTimeLabel = new QLabel("00:00", m_fullscreenWidget);
    m_fullscreenTimeLabel->setStyleSheet("color: white; background-color: rgba(0,0,0,150); padding: 2px 5px; border-radius: 3px;");
    m_fullscreenTimeLabel->setVisible(false);

    m_fullscreenTotalLabel = new QLabel("/ 00:00", m_fullscreenWidget);
    m_fullscreenTotalLabel->setStyleSheet("color: white; background-color: rgba(0,0,0,150); padding: 2px 5px; border-radius: 3px;");
    m_fullscreenTotalLabel->setVisible(false);

    m_fullscreenLayout->addWidget(m_fullscreenVideo);
    m_fullscreenLayout->addWidget(m_fullscreenView);

    // 进度条和时间标签需要单独定位（覆盖在视频上）
    m_fullscreenSlider->setParent(m_fullscreenWidget);
    m_fullscreenTimeLabel->setParent(m_fullscreenWidget);
    m_fullscreenTotalLabel->setParent(m_fullscreenWidget);

    QShortcut *escShortcut =
        new QShortcut(QKeySequence(Qt::Key_Escape),
                      m_fullscreenWidget);

    connect(escShortcut,
            &QShortcut::activated,
            this,
            [this]()
            {
                qDebug() << "ESC Shortcut Triggered";

                if (m_isFullscreen)
                    onFullscreen();
            });
}

void MainWindow::setupVolumeButton()
{
    ui->volumeSlider->setRange(0, 100);
    ui->volumeSlider->setValue(70);
    ui->volumeSlider->setVisible(false);
    ui->volumeSlider->setFixedWidth(100);
    ui->volumeSlider->setStyleSheet(
        "QSlider::groove:horizontal {"
        "   height: 6px;"
        "   background: #3d3d3d;"
        "   border-radius: 3px;"
        "}"
        "QSlider::sub-page:horizontal {"
        "   background: #4CAF50;"
        "   border-radius: 3px;"
        "}"
        "QSlider::handle:horizontal {"
        "   background: white;"
        "   width: 16px;"
        "   height: 16px;"
        "   margin: -5px 0;"
        "   border-radius: 8px;"
        "}"
        "QSlider::handle:horizontal:hover {"
        "   background: #4CAF50;"
        "}"
        );

    // 确保音量标签可见并设置样式
    ui->volumeLabel->setVisible(true);
    ui->volumeLabel->setStyleSheet("QLabel { color: white; font-size: 12px; min-width: 35px; }");

    m_volumeButton = new QPushButton(this);
    m_volumeButton->setFixedSize(36, 36);
    m_volumeButton->setCursor(Qt::PointingHandCursor);
    m_volumeButton->setStyleSheet(
        "QPushButton {"
        "   background-color: transparent;"
        "   border: none;"
        "}"
        "QPushButton:hover {"
        "   background-color: rgba(255, 255, 255, 0.1);"
        "   border-radius: 6px;"
        "}"
        );

    updateVolumeIcon(70);

    connect(ui->volumeSlider, &QSlider::valueChanged, this, [this](int value) {
        if (m_player->audioOutput()) {
            m_player->audioOutput()->setVolume(value / 100.0);
        }
        updateVolumeIcon(value);
        ui->volumeSlider->setToolTip(QString("音量: %1%").arg(value));
        // 更新音量标签
        ui->volumeLabel->setText(QString("%1%").arg(value));
    });

    connect(m_volumeButton, &QPushButton::clicked, this, [this]() {
        m_volumeButton->setVisible(false);
        ui->volumeSlider->setVisible(true);
        ui->volumeSlider->setFocus();
    });

    connect(ui->volumeSlider, &QSlider::sliderReleased, this, [this]() {
        ui->volumeSlider->setVisible(false);
        m_volumeButton->setVisible(true);
    });

    statusBar()->addPermanentWidget(m_volumeButton);
}

void MainWindow::updateVolumeIcon(int volume)
{
    QString iconPath;
    if (volume == 0) {
        iconPath = ":/new/prefix1/images/close.png";
    } else if (volume <= 33) {
        iconPath = ":/new/prefix1/images/whisper.png";
    } else if (volume <= 66) {
        iconPath = ":/new/prefix1/images/middle.png";
    } else {
        iconPath = ":/new/prefix1/images/maxup.png";
    }

    m_volumeButton->setIcon(QIcon(iconPath));
    m_volumeButton->setIconSize(QSize(28, 28));
    m_volumeButton->setText("");
    m_volumeButton->setToolTip(QString("音量: %1%").arg(volume));

    // 更新音量标签
    ui->volumeLabel->setText(QString("%1%").arg(volume));
}

void MainWindow::setupPlayer()
{
    m_playlistManager = new PlaylistManager(this);
    m_player = m_playlistManager->getPlayer();
    m_player->setVideoOutput(m_videoWidget);

    // 设置音频输出
    QAudioOutput *audioOutput = new QAudioOutput(this);
    audioOutput->setVolume(0.7);
    m_player->setAudioOutput(audioOutput);
}
void MainWindow::setupPlaylistView()
{
    ui->playlistWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->playlistWidget->setDragDropMode(QAbstractItemView::InternalMove);  // 启用内部拖拽
    ui->playlistWidget->setDefaultDropAction(Qt::MoveAction);

    connect(ui->playlistWidget, &QListWidget::doubleClicked, this, &MainWindow::onPlaylistDoubleClicked);
    connect(ui->playlistWidget, &QListWidget::customContextMenuRequested, this, &MainWindow::onPlaylistContextMenu);

    // 监听拖拽结束，保存新顺序
    connect(ui->playlistWidget->model(), &QAbstractItemModel::rowsMoved,
            this, &MainWindow::onPlaylistOrderChanged);
}
void MainWindow::setupConnections()
{
    connect(ui->openFileBtn, &QPushButton::clicked, this, &MainWindow::onOpenFile);
    connect(ui->openFolderBtn, &QPushButton::clicked, this, &MainWindow::onOpenFolder);
    connect(ui->clearBtn, &QPushButton::clicked, this, &MainWindow::onClearPlaylist);
    connect(ui->loadPlaylistBtn, &QPushButton::clicked, this, &MainWindow::onLoadPlaylist);
    connect(ui->savePlaylistBtn, &QPushButton::clicked, this, &MainWindow::onSavePlaylist);
    connect(ui->playBtn, &QPushButton::clicked, this, &MainWindow::onPlay);
    connect(ui->pauseBtn, &QPushButton::clicked, this, &MainWindow::onPause);
    connect(ui->stopBtn, &QPushButton::clicked, this, &MainWindow::onStop);
    connect(ui->prevBtn, &QPushButton::clicked, this, &MainWindow::onPrevious);
    connect(ui->nextBtn, &QPushButton::clicked, this, &MainWindow::onNext);
    connect(ui->modeBtn, &QPushButton::clicked, this, &MainWindow::onChangePlaybackMode);
    connect(ui->fullscreenBtn, &QPushButton::clicked, this, &MainWindow::onFullscreen);
    connect(m_player, &QMediaPlayer::playbackStateChanged, this, &MainWindow::onPlaybackStateChanged);
    connect(m_player, &QMediaPlayer::positionChanged, this, &MainWindow::onPositionChanged);
    connect(m_player, &QMediaPlayer::durationChanged, this, &MainWindow::onDurationChanged);
    connect(m_player, &QMediaPlayer::mediaStatusChanged, this, &MainWindow::onMediaStatusChanged);
    connect(m_player, &QMediaPlayer::sourceChanged, this, &MainWindow::onMediaChanged);
    connect(ui->progressSlider, &QSlider::sliderMoved, this, &MainWindow::onSeek);
    connect(m_playlistManager, &PlaylistManager::playlistChanged, this, &MainWindow::onPlaylistChanged);
    connect(m_playlistManager, &PlaylistManager::modeChanged, this, [this](QString mode) {
        ui->modeBtn->setText(mode);
    });
    connect(m_playlistManager, &PlaylistManager::currentIndexChanged, this, [this](int index) {
        if (index >= 0) {
            ui->playlistWidget->setCurrentRow(index);
        }
    });
}

void MainWindow::setupMenuBar()
{
    QMenu *fileMenu = menuBar()->addMenu("文件(&F)");
    QAction *openAction = fileMenu->addAction("打开文件(&O)");
    openAction->setShortcut(QKeySequence::Open);
    connect(openAction, &QAction::triggered, this, &MainWindow::onOpenFile);

    QAction *openFolderAction = fileMenu->addAction("打开文件夹(&D)");
    connect(openFolderAction, &QAction::triggered, this, &MainWindow::onOpenFolder);

    fileMenu->addSeparator();

    QAction *loadAction = fileMenu->addAction("加载播放列表(&L)");
    connect(loadAction, &QAction::triggered, this, &MainWindow::onLoadPlaylist);

    QAction *saveAction = fileMenu->addAction("保存播放列表(&S)");
    connect(saveAction, &QAction::triggered, this, &MainWindow::onSavePlaylist);

    fileMenu->addSeparator();

    QAction *exitAction = fileMenu->addAction("退出(&X)");
    connect(exitAction, &QAction::triggered, this, &QWidget::close);

    QMenu *playMenu = menuBar()->addMenu("播放(&P)");
    QAction *playAction = playMenu->addAction("播放(&P)");
    playAction->setShortcut(QKeySequence(Qt::Key_Space));
    connect(playAction, &QAction::triggered, this, &MainWindow::onPlay);

    QAction *pauseAction = playMenu->addAction("暂停(&U)");
    connect(pauseAction, &QAction::triggered, this, &MainWindow::onPause);

    QAction *stopAction = playMenu->addAction("停止(&S)");
    connect(stopAction, &QAction::triggered, this, &MainWindow::onStop);

    playMenu->addSeparator();

    QAction *prevAction = playMenu->addAction("上一曲(&R)");
    connect(prevAction, &QAction::triggered, this, &MainWindow::onPrevious);

    QAction *nextAction = playMenu->addAction("下一曲(&N)");
    connect(nextAction, &QAction::triggered, this, &MainWindow::onNext);

    playMenu->addSeparator();

    QAction *modeAction = playMenu->addAction("循环模式(&M)");
    connect(modeAction, &QAction::triggered, this, &MainWindow::onChangePlaybackMode);

    QMenu *viewMenu = menuBar()->addMenu("视图(&V)");
    QAction *fullAction = viewMenu->addAction("全屏(&F)");
    fullAction->setShortcut(QKeySequence::FullScreen);
    connect(fullAction, &QAction::triggered, this, &MainWindow::onFullscreen);

    QMenu *helpMenu = menuBar()->addMenu("帮助(&H)");
    QAction *aboutAction = helpMenu->addAction("关于(&A)");
    QMenu *speedMenu = playMenu->addMenu("播放速度(&S)");
    QAction *speed05 = speedMenu->addAction("0.5x");
    QAction *speed10 = speedMenu->addAction("1.0x");
    QAction *speed15 = speedMenu->addAction("1.5x");
    QAction *speed20 = speedMenu->addAction("2.0x");
    connect(speed05, &QAction::triggered, [this]() { setPlaybackSpeed(0.5); });
    connect(speed10, &QAction::triggered, [this]() { setPlaybackSpeed(1.0); });
    connect(speed15, &QAction::triggered, [this]() { setPlaybackSpeed(1.5); });
    connect(speed20, &QAction::triggered, [this]() { setPlaybackSpeed(2.0); });

}
void MainWindow::setPlaybackSpeed(double speed) {
    m_currentSpeed = speed;
    m_player->setPlaybackRate(speed);
    statusBar()->showMessage(QString("播放速度: %1x").arg(speed), 1500);
}
void MainWindow::setupDateTimeDisplay()
{
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, [=]() {
        QDateTime now = QDateTime::currentDateTime();
        ui->dateLabel->setText(now.toString("yyyy年MM月dd日"));
        ui->timeLabelDisplay->setText(now.toString("hh:mm:ss"));
        ui->weekdayLabel->setText(now.toString("dddd"));
    });
    timer->start(1000);
}

void MainWindow::onOpenFile()
{
    QStringList files = QFileDialog::getOpenFileNames(this, "选择媒体文件", QDir::homePath(),
                                                      "媒体文件 (*.mp3 *.wav *.mp4 *.avi *.mkv *.mov *.jpg *.jpeg *.png *.bmp)");
    if (!files.isEmpty()) addMediaFiles(files);
}

void MainWindow::onOpenFolder()
{
    QString dir = QFileDialog::getExistingDirectory(this, "选择文件夹");
    if (dir.isEmpty()) return;

    QStringList files;
    QDirIterator it(dir, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        it.next();
        if (!it.fileInfo().isDir()) {
            QString path = it.filePath();
            if (isImageFile(path) || isVideoFile(path) || isAudioFile(path))
                files.append(path);
        }
    }
    if (!files.isEmpty()) addMediaFiles(files);
}

void MainWindow::onClearPlaylist()
{
    if (m_playlistManager->getPlaylistSize() > 0 &&
        QMessageBox::question(this, "确认", "清空播放列表？") == QMessageBox::Yes) {
        m_playlistManager->clearPlaylist();
        ui->playlistWidget->clear();
        hideImage();
    }
}

void MainWindow::onLoadPlaylist()
{
    QString path = QFileDialog::getOpenFileName(this, "加载播放列表", QDir::homePath(), "*.m3u *.txt");
    if (!path.isEmpty() && m_playlistManager->loadPlaylist(path))
        statusBar()->showMessage("加载成功", 2000);
}

void MainWindow::onSavePlaylist()
{
    if (m_playlistManager->getPlaylistSize() == 0) {
        QMessageBox::information(this, "提示", "列表为空");
        return;
    }
    QString path = QFileDialog::getSaveFileName(this, "保存播放列表", QDir::homePath() + "/playlist.m3u", "*.m3u");
    if (!path.isEmpty() && m_playlistManager->savePlaylist(path))
        statusBar()->showMessage("保存成功", 2000);
}

void MainWindow::onPlay()
{
    if (m_playlistManager->getPlaylistSize() == 0) {
        QMessageBox::information(this, "提示", "请先添加媒体文件");
        return;
    }
    if (m_playlistManager->getCurrentIndex() == -1) {
        m_playlistManager->setCurrentIndex(0);
    }
    m_player->play();
}

void MainWindow::onPause() { m_player->pause(); }

void MainWindow::onStop()
{
    m_player->stop();
    ui->progressSlider->setValue(0);
    m_imageTimer->stop();
}

void MainWindow::onPrevious()
{
    if (m_playlistManager->getPlaylistSize() > 0) {
        m_playlistManager->playPrevious();
        m_player->play();
    }
}

void MainWindow::onNext()
{
    if (m_playlistManager->getPlaylistSize() > 0) {
        m_playlistManager->playNext();
        if (m_playlistManager->getCurrentIndex() >= 0) {
            m_player->play();
        }
    }
}

void MainWindow::onVolumeChanged(int value)
{
    if (m_player->audioOutput()) {
        m_player->audioOutput()->setVolume(value / 100.0);
    }
    updateVolumeIcon(value);
}

void MainWindow::onPositionChanged(qint64 pos)
{
    if (!ui->progressSlider->isSliderDown() && m_player->duration() > 0) {
        ui->progressSlider->setValue(int(pos * 100 / m_player->duration()));
    }
    int secs = pos / 1000;
    ui->timeLabel->setText(QString("%1:%2").arg(secs/60, 2, 10, QChar('0')).arg(secs%60, 2, 10, QChar('0')));

    // 同步全屏窗口的进度条和时间
    if (m_fullscreenWidget && m_fullscreenWidget->isVisible()) {
        if (m_player->duration() > 0) {
            m_fullscreenSlider->setValue(int(pos * 100 / m_player->duration()));
        }
        m_fullscreenTimeLabel->setText(QString("%1:%2").arg(secs/60, 2, 10, QChar('0')).arg(secs%60, 2, 10, QChar('0')));
    }

}

void MainWindow::onDurationChanged(qint64 dur)
{
    if (dur > 0) {
        int secs = dur / 1000;
        ui->totalTimeLabel->setText(QString("/ %1:%2").arg(secs/60, 2, 10, QChar('0')).arg(secs%60, 2, 10, QChar('0')));

        // 同步全屏窗口的总时间
        if (m_fullscreenWidget) {
            m_fullscreenTotalLabel->setText(QString("/ %1:%2").arg(secs/60, 2, 10, QChar('0')).arg(secs%60, 2, 10, QChar('0')));
        }
    }
}

void MainWindow::onSeek(int value)
{
    if (m_player->duration() > 0)
        m_player->setPosition(value * m_player->duration() / 100);
}

void MainWindow::onChangePlaybackMode()
{
    int next = (m_playlistManager->getPlaybackMode() + 1) % 5;
    m_playlistManager->setPlaybackMode(static_cast<PlaylistManager::PlaybackMode>(next));
}

void MainWindow::onMediaStatusChanged(QMediaPlayer::MediaStatus status)
{
    if (status == QMediaPlayer::EndOfMedia) {
        onNext();
    }
}

void MainWindow::onMediaChanged(const QUrl &content)
{
    QString path = content.toLocalFile();
    if (isImageFile(path)) {
        showImage(path);
        ui->graphicsView->setScene(m_imageScene);
        m_videoWidget->setVisible(false);
        ui->graphicsView->setVisible(true);
        m_imageTimer->start(m_imageDisplayDuration);
    } else if (isVideoFile(path)) {
        hideImage();
        ui->graphicsView->setScene(nullptr);
        m_videoWidget->setVisible(true);
        ui->graphicsView->setVisible(true);
        m_imageTimer->stop();
    } else if (isAudioFile(path)) {
        hideImage();
        m_videoWidget->setVisible(false);
        ui->graphicsView->setVisible(false);
        m_imageTimer->stop();
    }
}

void MainWindow::onPlaybackStateChanged(QMediaPlayer::PlaybackState state)
{
    m_isPlaying = (state == QMediaPlayer::PlayingState);
    ui->playBtn->setVisible(!m_isPlaying);
    ui->pauseBtn->setVisible(m_isPlaying);

    if (state == QMediaPlayer::PlayingState) {
        statusBar()->showMessage("正在播放", 1000);
    } else if (state == QMediaPlayer::PausedState) {
        statusBar()->showMessage("已暂停", 1000);
    } else if (state == QMediaPlayer::StoppedState) {
        statusBar()->showMessage("已停止", 1000);
    }
}

// ========== 独立全屏窗口功能 ==========
void MainWindow::onFullscreen()
{
    if (!m_isFullscreen) {
        // 进入全屏
        m_isFullscreen = true;

        // 判断当前是视频还是图片
        if (m_videoWidget && m_videoWidget->isVisible()) {
            // ========== 视频模式 ==========
            // 保存当前播放位置和状态
            qint64 currentPos = m_player->position();
            bool wasPlaying = (m_player->playbackState() == QMediaPlayer::PlayingState);

            // 先停止播放
            m_player->stop();

            // 显示全屏窗口
            m_fullscreenWidget->showFullScreen();

            // 设置视频输出到全屏窗口
            m_player->setVideoOutput(m_fullscreenVideo);

            // 恢复播放位置和状态
            m_player->setPosition(currentPos);
            if (wasPlaying) {
                m_player->play();
            }

            // 显示视频控件，隐藏图片控件
            m_fullscreenVideo->show();
            m_fullscreenView->hide();

        } else if (m_isImagePlaying && m_imageScene && !m_imageScene->items().isEmpty()) {
            // ========== 图片模式 ==========
            // 显示全屏窗口
            m_fullscreenWidget->showFullScreen();

            // 显示图片控件，隐藏视频控件
            m_fullscreenVideo->hide();
            m_fullscreenView->show();

            // 获取当前图片
            QGraphicsPixmapItem *item = qgraphicsitem_cast<QGraphicsPixmapItem*>(m_imageScene->items().first());
            if (item) {
                QPixmap pix = item->pixmap();
                if (!pix.isNull()) {
                    // 创建全屏图片场景
                    QGraphicsScene *fullScene = new QGraphicsScene(this);
                    QPixmap scaled = pix.scaled(m_fullscreenView->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
                    fullScene->addPixmap(scaled);
                    m_fullscreenView->setScene(fullScene);
                    m_fullscreenView->setSceneRect(scaled.rect());
                    m_fullscreenView->centerOn(scaled.width()/2, scaled.height()/2);
                }
            }
        } else {
            // 没有媒体文件，退出全屏
            m_fullscreenWidget->hide();
            m_isFullscreen = false;
            return;
        }

        // 显示进度条和时间
        m_fullscreenSlider->setVisible(true);
        m_fullscreenTimeLabel->setVisible(true);
        m_fullscreenTotalLabel->setVisible(true);

        // 同步当前进度
        if (m_player->duration() > 0) {
            int pos = int(m_player->position() * 100 / m_player->duration());
            m_fullscreenSlider->setValue(pos);
        }
        int secs = m_player->position() / 1000;
        m_fullscreenTimeLabel->setText(QString("%1:%2").arg(secs/60, 2, 10, QChar('0')).arg(secs%60, 2, 10, QChar('0')));

        int totalSecs = m_player->duration() / 1000;
        m_fullscreenTotalLabel->setText(QString("/ %1:%2").arg(totalSecs/60, 2, 10, QChar('0')).arg(totalSecs%60, 2, 10, QChar('0')));

        // 连接全屏进度条
        connect(m_fullscreenSlider, &QSlider::sliderMoved, this, &MainWindow::onSeek);

        // 设置全屏窗口的控件位置
        m_fullscreenSlider->setGeometry(10, m_fullscreenWidget->height() - 40, m_fullscreenWidget->width() - 20, 20);
        m_fullscreenTimeLabel->setGeometry(10, m_fullscreenWidget->height() - 60, 45, 20);
        m_fullscreenTotalLabel->setGeometry(m_fullscreenWidget->width() - 55, m_fullscreenWidget->height() - 60, 50, 20);

    } else
    {
        qDebug() << "1";

        m_isFullscreen = false;

        qDebug() << "2";

        disconnect(m_fullscreenSlider,
                   &QSlider::sliderMoved,
                   this,
                   &MainWindow::onSeek);

        qDebug() << "3";

        qint64 currentPos = m_player->position();

        qDebug() << "4";

        bool wasPlaying =
            (m_player->playbackState() == QMediaPlayer::PlayingState);

        qDebug() << "5";

        m_player->stop();

        qDebug() << "6";

        m_fullscreenWidget->hide();

        qDebug() << "7";

        m_player->setVideoOutput(m_videoWidget);

        qDebug() << "8";

        m_player->setPosition(currentPos);

        qDebug() << "9";

        if (wasPlaying)
            m_player->play();

        qDebug() << "10";

        update();

        qDebug() << "11";
        qDebug() << "12";

        if (m_fullscreenView->scene()) {
            qDebug() << "13";
            m_fullscreenView->setScene(nullptr);
            qDebug() << "14";
        }

        qDebug() << "15";
    }
}

void MainWindow::onPlaylistDoubleClicked(const QModelIndex &index)
{
    m_playlistManager->setCurrentIndex(index.row());
    m_player->play();
}

void MainWindow::onPlaylistContextMenu(const QPoint &pos)
{
    QListWidgetItem *item = ui->playlistWidget->itemAt(pos);
    if (item) {
        QMenu menu;
        if (menu.exec(ui->playlistWidget->mapToGlobal(pos)) == menu.addAction("移除"))
            m_playlistManager->removeMedia(ui->playlistWidget->row(item));
    }
}

void MainWindow::onPlaylistChanged()
{
    updatePlaylistModel();
}

void MainWindow::onImageTimerTimeout()
{
    if (m_playlistManager->getPlaylistSize() > 0) {
        onNext();
    }
}

void MainWindow::updatePlaylistModel()
{
    ui->playlistWidget->clear();
    for (int i = 0; i < m_playlistManager->getPlaylistSize(); ++i)
        ui->playlistWidget->addItem(m_playlistManager->getMediaTitle(i));
    statusBar()->showMessage(QString("共 %1 个项目").arg(m_playlistManager->getPlaylistSize()), 2000);
}

void MainWindow::showImage(const QString &path)
{
    QPixmap pix(path);
    if (!pix.isNull()) {
        QPixmap scaled = pix.scaled(ui->graphicsView->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
        m_imageScene->clear();
        m_imageItem = m_imageScene->addPixmap(scaled);
        ui->graphicsView->setSceneRect(scaled.rect());
        setWindowTitle(QString("轮播展示播放器 - %1").arg(QFileInfo(path).fileName()));
        m_isImagePlaying = true;
        m_isPlaying = true;
    }
}

void MainWindow::hideImage() { if (m_imageScene) m_imageScene->clear(); }

bool MainWindow::isImageFile(const QString &path) {
    QString s = QFileInfo(path).suffix().toLower();
    return s == "jpg" || s == "jpeg" || s == "png" || s == "bmp" || s == "gif";
}

bool MainWindow::isVideoFile(const QString &path) {
    QString s = QFileInfo(path).suffix().toLower();
    return s == "mp4" || s == "avi" || s == "mkv" || s == "mov";
}

bool MainWindow::isAudioFile(const QString &path) {
    QString s = QFileInfo(path).suffix().toLower();
    return s == "mp3" || s == "wav" || s == "flac" || s == "ogg";
}

void MainWindow::addMediaFiles(const QStringList &paths)
{
    QStringList valid;
    for (const QString &p : paths)
        if (isImageFile(p) || isVideoFile(p) || isAudioFile(p)) valid.append(p);
    if (!valid.isEmpty()) {
        m_playlistManager->addMedias(valid);
        if (m_playlistManager->getCurrentIndex() == -1 && m_playlistManager->getPlaylistSize() > 0) {
            m_playlistManager->setCurrentIndex(0);
        }
    }
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);

    // 重新缩放主窗口图片
    if (m_isImagePlaying && m_imageScene && !m_imageScene->items().isEmpty()) {
        QGraphicsPixmapItem *item = qgraphicsitem_cast<QGraphicsPixmapItem*>(m_imageScene->items().first());
        if (item) {
            QPixmap pix = item->pixmap();
            if (!pix.isNull()) {
                QPixmap scaled = pix.scaled(ui->graphicsView->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
                item->setPixmap(scaled);
                ui->graphicsView->setSceneRect(scaled.rect());
            }
        }
    }

    // 调整主窗口视频大小
    if (m_videoWidget && m_videoWidget->isVisible()) {
        m_videoWidget->setGeometry(0, 0, ui->graphicsView->width(), ui->graphicsView->height());
    }

    // 调整全屏窗口控件位置
    if (m_fullscreenWidget && m_fullscreenWidget->isVisible()) {
        int w = m_fullscreenWidget->width();
        int h = m_fullscreenWidget->height();

        m_fullscreenSlider->setGeometry(10, h - 40, w - 20, 20);
        m_fullscreenTimeLabel->setGeometry(10, h - 60, 45, 20);
        m_fullscreenTotalLabel->setGeometry(w - 55, h - 60, 50, 20);

        // 全屏时调整视频大小
        if (m_fullscreenVideo && m_fullscreenVideo->isVisible()) {
            m_fullscreenVideo->setGeometry(0, 0, w, h);
        }

        // 全屏时重新缩放图片
        if (m_fullscreenView && m_fullscreenView->isVisible() && m_fullscreenView->scene()) {
            QGraphicsScene *scene = m_fullscreenView->scene();
            QList<QGraphicsItem*> items = scene->items();
            if (!items.isEmpty()) {
                QGraphicsPixmapItem *item = qgraphicsitem_cast<QGraphicsPixmapItem*>(items.first());
                if (item) {
                    QPixmap pix = item->pixmap();
                    if (!pix.isNull()) {
                        QPixmap scaled = pix.scaled(w, h, Qt::KeepAspectRatio, Qt::SmoothTransformation);
                        item->setPixmap(scaled);
                        m_fullscreenView->setSceneRect(scaled.rect());
                        m_fullscreenView->centerOn(scaled.width()/2, scaled.height()/2);
                    }
                }
            }
        }
    }
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event)//拖拽
{
    if (event->mimeData()->hasUrls()) event->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent *event)
{
    QStringList files;
    for (const QUrl &url : event->mimeData()->urls())
        files.append(url.toLocalFile());
    addMediaFiles(files);
}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
    return QMainWindow::eventFilter(obj, event);
}
void MainWindow::setupShortcuts()
{

    // 上下方向键调音量
    QShortcut *upShortcut = new QShortcut(QKeySequence(Qt::Key_Up), this);
    connect(upShortcut, &QShortcut::activated, [this]() {
        int vol = ui->volumeSlider->value() + 5;
        ui->volumeSlider->setValue(qMin(vol, 100));
    });

}
void MainWindow::wheelEvent(QWheelEvent *event)
{
    int delta = event->angleDelta().y();
    if (delta != 0) {
        int step = delta / 120;  // 通常一个刻度是120
        int newVol = ui->volumeSlider->value() + step * 5;
        ui->volumeSlider->setValue(qBound(0, newVol, 100));
        statusBar()->showMessage(QString("音量: %1%").arg(ui->volumeSlider->value()), 500);
    }
    event->accept();
}
void MainWindow::onPlaylistOrderChanged()
{
    // 获取新的播放列表顺序
    QStringList newOrder;
    for (int i = 0; i < ui->playlistWidget->count(); ++i) {
        QString title = ui->playlistWidget->item(i)->text();
        // 根据标题找到对应的文件路径
        for (int j = 0; j < m_playlistManager->getPlaylistSize(); ++j) {
            if (m_playlistManager->getMediaTitle(j) == title) {
                newOrder.append(m_playlistManager->getMediaUrl(j).toLocalFile());
                break;
            }
        }
    }

    // 重新构建播放列表
    if (!newOrder.isEmpty()) {
        m_playlistManager->clearPlaylist();
        m_playlistManager->addMedias(newOrder);
    }
}