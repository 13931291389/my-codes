QT += core gui multimedia multimediawidgets widgets

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    playlistmanager.cpp

HEADERS += \
    mainwindow.h \
    playlistmanager.h

FORMS += \
    mainwindow.ui

RESOURCES += \
    image.qrc
