#include "audiovisualizer.h"
#include <QPainter>

AudioVisualizer::AudioVisualizer(QWidget *parent) : QWidget(parent)
{
    m_amplitudes.fill(0, 30);
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, QOverload<>::of(&QWidget::update));
    m_timer->start(50);
    setFixedSize(150, 25);
}

void AudioVisualizer::addAmplitude(int value)
{
    m_amplitudes.append(qBound(0, value, 100));
    if (m_amplitudes.size() > 30) m_amplitudes.removeFirst();
}

void AudioVisualizer::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setBrush(Qt::green);

    int w = width() / m_amplitudes.size();
    for (int i = 0; i < m_amplitudes.size(); ++i) {
        int h = (m_amplitudes[i] * height()) / 100;
        painter.fillRect(i * w, height() - h, w - 1, h, Qt::green);
    }
}