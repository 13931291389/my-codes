#ifndef PLAYLISTMANAGER_H
#define PLAYLISTMANAGER_H

#include <QObject>
#include <QMediaPlayer>
#include <QUrl>
#include <QList>

class PlaylistManager : public QObject
{
    Q_OBJECT

public:
    enum PlaybackMode {
        CurrentItemOnce,
        CurrentItemLoop,
        Sequential,
        Loop,
        Random
    };
    Q_ENUM(PlaybackMode)

    explicit PlaylistManager(QObject *parent = nullptr);
    ~PlaylistManager();

    void addMedia(const QString &filePath);
    void addMedias(const QStringList &filePaths);
    void removeMedia(int index);
    void clearPlaylist();

    QMediaPlayer *getPlayer() const { return m_player; }
    QString getMediaTitle(int index) const;
    int getPlaylistSize() const { return m_playlist.size(); }
    QUrl getMediaUrl(int index) const { return m_playlist.value(index); }
    int getCurrentIndex() const { return m_currentIndex; }

    void setPlaybackMode(PlaybackMode mode);
    PlaybackMode getPlaybackMode() const { return m_currentMode; }
    QString getPlaybackModeText() const;

    void playNext();
    void playPrevious();
    void playCurrent();
    void setCurrentIndex(int index);

    bool loadPlaylist(const QString &filePath);
    bool savePlaylist(const QString &filePath);

signals:
    void playlistChanged();
    void currentIndexChanged(int index);
    void modeChanged(QString mode);

private:
    void updatePlayer();
    int getNextIndex();

private:
    QList<QUrl> m_playlist;
    QMediaPlayer *m_player;
    int m_currentIndex;
    PlaybackMode m_currentMode;
};

#endif