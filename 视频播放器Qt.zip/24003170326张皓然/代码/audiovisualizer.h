#ifndef AUDIOVISUALIZER_H
#define AUDIOVISUALIZER_H

#include <QWidget>
#include <QVector>
#include <QTimer>

class AudioVisualizer : public QWidget {
    Q_OBJECT
public:
    explicit AudioVisualizer(QWidget *parent = nullptr);
    void addAmplitude(int value);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QVector<int> m_amplitudes;
    QTimer *m_timer;
};

#endif